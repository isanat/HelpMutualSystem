// Arquivo: src/components/Header.tsx

"use client";

import { Button } from "./ui/button";
import { useWeb3 } from "../context/Web3Context";
import { useTranslation } from "react-i18next";
import Link from "next/link";

export default function Header() {
  const { t } = useTranslation();
  const { account, disconnectWallet, connectWallet, isOwner } = useWeb3();

  return (
    <header className="flex flex-col sm:flex-row justify-between items-center p-4 bg-[#0c0c0c] text-white gap-3 sm:gap-0">
      <div className="text-lg sm:text-xl font-bold text-center sm:text-left">
        <span className="text-green-500">Help</span>MutualSystem
      </div>
      <div className="flex flex-wrap justify-center items-center gap-2">
        {account ? (
          <>
            <span className="text-xs sm:text-sm flex items-center px-2">
              {account.slice(0, 6)}...{account.slice(-4)}
            </span>
            {isOwner && (
              <Link href="/backend">
                <Button
                  variant="outline"
                  className="text-xs sm:text-sm px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white border-none rounded-lg transition-colors"
                  aria-label={t('admin.panel', 'Admin Panel')}
                >
                  {t('admin.panel', 'Admin Panel')}
                </Button>
              </Link>
            )}
            <Button
              variant="danger"
              className="text-xs sm:text-sm px-3 py-1"
              onClick={disconnectWallet}
              aria-label={t('logout', 'Disconnect')}
            >
              {t('logout', 'Disconnect')}
            </Button>
          </>
        ) : (
          <Button
            className="text-xs sm:text-sm px-3 py-1"
            onClick={() => connectWallet('metamask')}
            aria-label="Connect Wallet"
          >
            Connect Wallet
          </Button>
        )}
      </div>
    </header>
  );
}