// Arquivo: src/components/StatusCard.tsx

"use client";

import { Card } from "./ui/card";
import { useTranslation } from "react-i18next";
import { ExternalLink } from "lucide-react";

interface UserInfo {
  isRegistered: boolean;
  registrationDate: string;
  sponsor: string;
  queuePosition: number;
  donationsReceived: number;
  hasDonated: boolean;
  entryFee: number;
  isInQueue: boolean;
  lockedAmount: number;
  unlockTimestamp: number;
}

interface StatusCardProps {
  userInfo: UserInfo | null;
}

export default function StatusCard({ userInfo }: StatusCardProps) {
  const { t } = useTranslation();

  const formatDate = (dateString: string | number) =>
    new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });

  if (!userInfo) {
    return (
      <Card className="p-4 sm:p-6">
        <h3 className="text-lg sm:text-xl font-semibold mb-4">{t('dashboard.status', 'Status')}</h3>
        <p className="text-sm text-gray-400">Loading user info...</p>
      </Card>
    );
  }

  return (
    <Card className="p-4 sm:p-6">
      <h3 className="text-lg sm:text-xl font-semibold mb-4">{t('dashboard.status', 'Status')}</h3>
      <p
        className={`text-sm sm:text-base mb-2 ${
          userInfo.isRegistered ? "text-green-500" : "text-red-500"
        }`}
      >
        {userInfo.isRegistered ? t('status.registered', 'Registered') : "Not Registered"}
      </p>
      {userInfo.isRegistered && (
        <>
          <p className="text-sm text-gray-400 mb-1">
            {t('status.registered', 'Registered at')}: {formatDate(userInfo.registrationDate)}
          </p>
          <p className="text-sm text-gray-400 mb-2">
            {t('status.sponsor', 'Sponsor')}:{' '}
            <a
              href={`${process.env.NEXT_PUBLIC_EXPLORER_URL}/address/${userInfo.sponsor}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-400 hover:underline"
            >
              {userInfo.sponsor.slice(0, 6)}...{userInfo.sponsor.slice(-4)}
              <ExternalLink size={14} className="inline ml-1" />
            </a>
          </p>
          <p className="text-sm text-gray-200 mb-1">
            {t('status.queue', 'Queue Position')}: {userInfo.isInQueue ? userInfo.queuePosition : "Not in queue"}
          </p>
          <p className="text-sm text-gray-200 mb-1">
            {t('status.donations', 'Donations Received')}: {userInfo.donationsReceived}
          </p>
          <p className="text-sm text-gray-200 mb-1">
            {t('status.hasDonated', 'Has Donated')}: {userInfo.hasDonated ? "Yes" : t('status.no', 'No')}
          </p>
          {userInfo.lockedAmount > 0 && (
            <>
              <p className="text-sm text-gray-200 mb-1">
                {t('incentive.lockedAmount', 'Locked Amount')}: {userInfo.lockedAmount} HELP
              </p>
              <p className="text-sm text-gray-200 mb-1">
                {t('incentive.unlockDate', 'Unlock Date')}: {formatDate(userInfo.unlockTimestamp * 1000)}
              </p>
            </>
          )}
          <p className="text-xs text-green-500">Entry Fee: {userInfo.entryFee} USDT</p>
        </>
      )}
    </Card>
  );
}